
print "hello from python world"
